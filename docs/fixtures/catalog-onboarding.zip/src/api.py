from src.store import read
@app.get('/record')
def record(): return read()